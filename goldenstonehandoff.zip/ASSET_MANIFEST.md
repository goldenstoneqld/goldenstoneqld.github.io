# Asset Manifest

Ten photographs extracted from the Capability Statement .docx and prepared for
the web. **These are Golden Stone's own production and project photography** —
real factory, real installs. They replace every stock or placeholder image on
the current site.

## Delivery

Copy `assets/images/*` into the website repository at **`public/images/`**.

> `public/images/` already holds `factory.png` and `public/images/suppliers/*`.
> Those are user-uploaded — **never overwrite them.** The filenames below do not
> collide with anything currently in the repository.

Each photo ships in four files: two widths × two formats.

```
<name>.jpg        1600w (or native, if narrower)  — fallback
<name>.webp       same width                      — preferred, ~50 % smaller
<name>-800w.jpg   800w                            — mobile fallback
<name>-800w.webp  800w                            — mobile preferred
```

Total payload: **3.3 MB across 40 files.** No single image exceeds 233 KB.

## Markup pattern

No build step exists, so serve WebP with a JPEG fallback by hand:

```html
<picture>
  <source
    type="image/webp"
    srcset="public/images/NAME-800w.webp 800w, public/images/NAME.webp 1600w"
    sizes="(max-width: 768px) 100vw, 50vw">
  <img
    src="public/images/NAME.jpg"
    srcset="public/images/NAME-800w.jpg 800w, public/images/NAME.jpg 1600w"
    sizes="(max-width: 768px) 100vw, 50vw"
    width="1600" height="1231"
    alt="…"
    loading="lazy" decoding="async">
</picture>
```

- The **hero image only** uses `loading="eager"` + `fetchpriority="high"`.
  Everything else is `loading="lazy"`.
- Always set `width`/`height` from the table below so nothing shifts on load
  (CLS).

## The photographs

| File stem | Native | Subject | Alt text (use verbatim) | Where it goes |
|---|---|---|---|---|
| `hero-kitchen-island-marble` | 1086×835 | Long white marble-look island running into a butler's pantry, brass tapware, pendant lights | *Kitchen island and benchtop in white marble-look stone, fabricated and installed by Golden Stone QLD.* | **Home hero.** The one image above the fold. Eager-loaded. |
| `craft-stonemason-measuring` | 1086×1392 | Stonemason in mask and ear defenders measuring a slab against a drawing, portrait orientation | *A Golden Stone stonemason checking slab dimensions against the fabrication drawing.* | About page "People & quality"; portrait, pairs with a text column |
| `craft-stonemason-detail` | 1086×587 | Closer crop of the same measure, tape and drawing in frame, wide letterbox | *Tape measure and fabrication drawing on a slab during dimensional checking.* | Home — banner strip above the IFL lifecycle section |
| `fab-cnc-bridge-saw` | 1458×941 | Blue CNC bridge saw on the factory floor, slab racks behind | *CNC bridge saw in the Golden Stone fabrication facility at Moorang.* | "In-house fabrication" — equipment card 1 |
| `fab-automated-polishing-line` | 1458×941 | Automated edge polishing line, spindle heads over the belt | *Automated polishing line used for edge processing and finishing.* | "In-house fabrication" — equipment card 2 |
| `fab-factory-floor-wide` | 1672×759 | Wide shot of the workshop: polishing line left, bridge saw right | *The Golden Stone workshop floor, with the polishing line and bridge saw in operation.* | Full-bleed section break between fabrication and projects |
| `project-residential-kitchen` | 1086×804 | Island with undermount sink, black stools, full-height splashback behind | *Residential kitchen island with integrated sink cut-out and matching splashback.* | Projects grid — "Residential Kitchen" |
| `project-full-height-splashback` | 1086×804 | Full-height veined splashback behind a cooktop, brass handles | *Full-height stone splashback paired with a matching benchtop and cooktop cut-out.* | Projects grid — "Full-Height Splashback" |
| `project-butlers-pantry` | 1086×804 | Butler's pantry corner run, open shelving, rattan wall pieces | *Butler's pantry with a continuous stone worktop and internal corner detailing.* | Projects grid — "Butler's Pantry" |
| `project-alfresco-outdoor` | 1279×948 | Outdoor brick alfresco kitchen, stone benchtop, black tap and sink | *Outdoor alfresco benchtop and sink area in brick and stone.* | Projects grid — "Outdoor / Alfresco" |

### Height reference for `width`/`height` attributes

| Stem | 1600w file | 800w file |
|---|---|---|
| `hero-kitchen-island-marble` | 1086×835 | 800×615 |
| `craft-stonemason-measuring` | 1086×1392 | 800×1025 |
| `craft-stonemason-detail` | 1086×587 | 800×432 |
| `fab-cnc-bridge-saw` | 1458×941 | 800×516 |
| `fab-automated-polishing-line` | 1458×941 | 800×516 |
| `fab-factory-floor-wide` | 1600×726 | 800×363 |
| `project-residential-kitchen` | 1086×804 | 800×592 |
| `project-full-height-splashback` | 1086×804 | 800×592 |
| `project-butlers-pantry` | 1086×804 | 800×592 |
| `project-alfresco-outdoor` | 1279×948 | 800×593 |

> Six of the ten are narrower than 1600 px natively — they were **not upscaled**.
> The `.jpg`/`.webp` pair simply carries the native width. That is deliberate:
> upscaling would add weight and no detail.

## Faces and consent

`craft-stonemason-measuring` and `craft-stonemason-detail` show an identifiable
person (wearing a respirator and ear defenders). They came from Golden Stone's
own capability statement, so publication is presumed intended — but if the
person shown is not a current team member, flag it rather than publishing.

## Provenance

Source: `Golden Stone QLD Capability Statement Draft 01.docx`, `word/media/`.
Re-encoded with Pillow — JPEG q82 progressive, WebP q80 method 6, Lanczos
resampling. Originals are unmodified inside the .docx.

# Golden Stone QLD — Website Redesign Brief

**Repository:** `goldenstoneqld/goldenstoneqld.github.io` (GitHub Pages user site)
**Live at:** https://goldenstoneqld.com.au
**Stack:** hand-written HTML5 + CSS + vanilla JS. No framework, no build step, no npm.
**Language:** Australian English in all copy, comments and filenames.

---

## 1. The brief in one paragraph

Golden Stone QLD is a stonemason in South East Queensland that runs a genuinely
integrated operation: it templates, cuts, polishes, quality-checks and installs
in-house, on its own CNC bridge saw and automated polishing line. Almost nobody
at its size does that, and the current website does not say so. The redesign
turns the Capability Statement into the site: real photography of the actual
factory and actual installs, the ten-step lifecycle rendered as the spine of the
home page, and an opening animation that shows a benchtop going from dimensioned
plan to fabricated stone. The result should read like the capability statement
of a manufacturer, not the brochure of a tradesman.

**The test to design against:** a kitchen designer or builder lands on the home
page and, within one screen and one scroll, understands that this business
controls the whole chain and can prove it.

---

## 2. Art direction

### 2.1 Palette — unchanged, and that is deliberate

The brand stays exactly as `docs/brand/brand-book.md` v2.0 and
`src/styles/tokens.css` define it:

| Role | Token | Value |
|---|---|---|
| Brand | `--colour-gold` | `#B8922A` Brass Gold |
| Anchor | `--colour-black` | `#111111` Deep Black |
| Page | `--colour-bg` | `#F5F0E8` Warm Cream |
| Surface | `--colour-surface` | `#EDE7DA` |
| Dark surface | `--colour-surface-dark` | `#1C1A18` |

**No teal. No new accent colour. Do not introduce a second brand hue.**

The IFL SaaS product has its own palette (Graphite & Stone, teal `#0E7C7B`).
That palette does **not** come across. What comes across from IFL is *rigour*:

- the **animation** (see §4), retinted to Brass Gold;
- **monospace for every millimetre figure, dimension and step number** — numbers
  that describe physical reality get a mono face, the way they do on a drawing;
- the **vocabulary of a controlled process** — gates, checks, hand-offs, states;
- **token discipline** — every colour, space and duration comes from
  `tokens.css`. No literal hex values in components. Ever.

### 2.2 Typography

Already loaded and correct: **Barlow Semi Condensed** 600/700 for display,
**DM Sans** 400/500 for body. Keep both.

Add one thing: a **monospace stack** for technical figures. Do not pull another
webfont for it — use the system stack already declared in
`assets/hero-animation/hero-animation.css`:

```css
--font-mono: ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace;
```

Use it for: step numbers (01–10), millimetre dimensions, the ABN, the phone
number in the footer, and the stat-row figures' units. Nowhere else.

### 2.3 The look

Warm cream ground, deep black sections for weight, gold used **sparingly** —
a rule, a numeral, a hairline under a heading, the CTA. Gold is punctuation, not
paint. Generous vertical rhythm (`--space-24` between major sections on
desktop). Large, confident type. Photography full-bleed or edge-anchored, never
floating in a rounded card with a drop shadow.

The current site's `--radius-lg: 12px` cards read soft. Prefer `--radius-md` or
square edges on large surfaces; stone is not rounded.

---

## 3. Page structure

Five pages. Four exist; `capability.html` is new.

### 3.1 `index.html` — Home

| # | Section | Content source | Notes |
|---|---|---|---|
| 1 | **Hero** | `CONTENT_SOURCE.md` §2 | Split: headline + CTA left, the animation (§4) right. On mobile the animation sits under the copy. H1 = "Crafted in Stone. Built to Last." Sub = the one-line descriptor. Two CTAs: *Request a quote* (gold, → contact.html) and *View our capability* (ghost, → capability.html). |
| 2 | **Stat row** | §5 | 15+ / IN-HOUSE / SEQ / END-TO-END. Four columns desktop, 2×2 mobile. Numerals in Barlow display size, gold hairline above each. This strip is the single highest-value element on the page — give it room. |
| 3 | **Services** | §4 | Five services. Keep the existing `#services` anchor. |
| 4 | **IFL lifecycle** | §6 | **The centrepiece.** See §5 of this brief for how to build it. Dark section (`--colour-surface-dark`). |
| 5 | **In-house fabrication** | §7 | Two equipment cards with `fab-cnc-bridge-saw` and `fab-automated-polishing-line`. Capability list below. Factory address line. |
| 6 | **Full-bleed break** | — | `fab-factory-floor-wide`, edge to edge, with the caption from §7 overlaid bottom-left. |
| 7 | **Selected projects** | §8 | Four-card grid, the four `project-*` photos. Keep `#projects`. |
| 8 | **Suppliers** | §11 | Existing logos, existing links. Do not touch the files. |
| 9 | **Why Golden Stone** | §12 | Six points. |
| 10 | **CTA** | §13 | Dark. Keep `#contact` anchor. |

Existing anchors `#services`, `#why-us`, `#about`, `#projects`, `#contact` must
keep working — they are linked from the nav on every page.

### 3.2 `capability.html` — NEW

The Capability Statement as a web page: a document a builder can read on a phone
or send to a client. Sections, in order, from `CONTENT_SOURCE.md`: §3 Who we are
→ §4 Core services → §5 Capability at a glance + materials → §6 IFL (full ten
steps + "what this means for clients") → §7 In-house fabrication → §9 Typical
scope → §8 Selected projects → §10 People & quality → §11 Suppliers → §12 Why →
§13 CTA.

Give it a print stylesheet (`@media print`) so it prints clean on A4: white
ground, black text, no dark sections, no navigation, URLs after links, page
breaks between major sections. That is what makes it a *capability statement*
rather than another marketing page.

### 3.3 `about.html`

Rebuild against §3, §10 and §12. Use `craft-stonemason-measuring` (portrait)
beside the team copy. Keep the existing "Where We Work" section and update it to
the seven-region line in `CONTENT_SOURCE.md` §1.

### 3.4 `contact.html`

**Do not redesign the form logic.** `src/scripts/contact.js` (306 lines) posts
to a Google Apps Script endpoint (`apps-script/Code.gs`); its field names are a
contract with that endpoint. Restyle only. Then correct the contact details and
add the factory address alongside the office address.

### 3.5 `docs/design-system.html`

Update to reflect whatever new component classes get added. It is the reference
page; leaving it stale defeats its purpose.

---

## 4. The opening animation

`assets/hero-animation/` holds a ported, self-contained version of the IFL login
entrance. Open `hero-animation.html` in a browser to see it.

**What it is:** a real Golden Stone L-run — 3200 × 650 with a 2400 return, a
700 × 400 undermount sink and a 600 cooktop — that draws itself as a dimensioned
plan, lifts into 3D, and materialises as polished stone with a sheen pass. Pure
SVG + CSS. 10-second loop. No JavaScript, no video, no library. About 5 KB.

**Install:**

1. Copy `hero-animation.css` to `src/styles/components/hero-animation.css`
   (or append to `components.css` — either is fine, one import either way).
2. Copy the markup between the `COMPONENT STARTS/ENDS HERE` comments in
   `hero-animation.html` into the home hero.
3. It reads `--colour-gold` from `tokens.css` automatically. The remaining
   custom properties at the top of `.hero-scene` are tuned for a **dark**
   backdrop — if the hero ends up on Warm Cream instead of Deep Black, retune
   `--hero-grid`, `--hero-dim-line`, `--hero-dim-text` and `--hero-label` to
   dark-on-light values. Do not edit anything below the retheme block.

**Rules:**

- The SVG is `aria-hidden="true"` — it is decoration, it must stay silent to
  screen readers.
- `prefers-reduced-motion` is already handled: motion stops and the finished
  benchtop shows. **Verify this still works after integration** — it is the one
  thing most likely to break.
- The dimensions on screen are real. If you change the geometry, change the
  figures to match. A wrong dimension on a stonemason's website is worse than no
  dimension.

---

## 5. The IFL lifecycle section — how to build it

This is the section that separates this site from every competitor's, so it gets
the most design attention.

Ten steps (`CONTENT_SOURCE.md` §6), each with a two-digit number, a name and a
short descriptor. Do **not** render it as ten identical boxes in a grid — that
reads as a feature list and throws away the point, which is that these steps are
*connected*.

**Suggested treatment** — a horizontal process rail on desktop:

- A single gold hairline runs the width of the section, with ten nodes on it.
- Each node: mono step number above the line, name in Barlow below it,
  descriptor in DM Sans small underneath.
- On desktop the rail scrolls horizontally within the section (CSS
  `scroll-snap-type: x mandatory`) or wraps to 5 × 2 — whichever holds
  legibility at 1024 px without shrinking type below 14 px.
- On mobile it becomes a vertical timeline: the gold line runs down the left
  edge, nodes stack.
- Steps 03 (Measure), 06 (Cut), 07 (Polish) and 09 (Install) are the ones the
  photographs evidence — consider linking or visually tying those four to the
  fabrication section below.

If a scroll-driven reveal is added, gate it behind `prefers-reduced-motion` and
make sure every step is readable with JavaScript disabled. **The content must
not depend on script.**

Close the section with the strapline and the six "what this means for clients"
points.

---

## 6. Non-negotiables

### Performance budget

This is a static site on a CDN with no framework. There is no excuse for it to
be slow. Targets on a mid-range mobile, 4G:

- **LCP < 2.0 s.** The LCP element is the hero — either the H1 or
  `hero-kitchen-island-marble`. Preload it, `fetchpriority="high"`, never lazy.
- **CLS < 0.05.** Every `<img>` carries explicit `width` and `height`.
- **Total JS < 15 KB** unminified across the whole site. Today it is ~10 KB
  (`main.js` + `contact.js`). Do not exceed 15.
- **No render-blocking third-party requests** other than the existing Google
  Fonts import. Consider `<link rel="preconnect">` to `fonts.gstatic.com`.
- Every photograph uses the `<picture>` pattern in `ASSET_MANIFEST.md`.

### Accessibility

- Colour contrast ≥ 4.5:1 for body text, ≥ 3:1 for large text and UI borders.

  **Two tokens in the current palette fail against Warm Cream. Measured:**

  | Pair | Ratio | Verdict |
  |---|---|---|
  | `--colour-gold` `#B8922A` on cream | **2.58:1** | fails body **and** large text |
  | `--colour-stone` `#9E9790` on cream | **2.54:1** | fails — yet tokens.css assigns it to "sub-labels, secondary/muted text" |
  | `--colour-gold-dark` `#7A5F1A` on cream | 5.32:1 | passes |
  | `--colour-text-sec` `#5C5650` on cream | 6.38:1 | passes |
  | `--colour-text` `#111111` on cream | 16.65:1 | passes |
  | `--colour-gold` on black `#111111` | 6.46:1 | passes |
  | `--colour-gold` on `#1C1A18` | 5.93:1 | passes |

  So: **gold is a dark-background colour.** On Warm Cream it may be used only for
  non-informational decoration — rules, dividers, a bar mark, the fill of a
  shape — never for text or for anything a user must read or distinguish. For
  text on cream use `--colour-text`, `--colour-text-sec`, or `--colour-gold-dark`
  when the accent must read as gold.

  **`--colour-stone` for muted text on cream is an existing defect on the live
  site.** Fix it as part of this work: either darken the token or stop using it
  for text. Note the change in the PR — it touches the brand book.
- Every interactive element reachable and visible on keyboard focus
  (`--shadow-focus` exists — use it).
- One `<h1>` per page; heading levels never skip.
- The mobile menu must trap focus and close on `Escape`.
- All decorative imagery `aria-hidden`; all meaningful imagery gets the alt text
  from `ASSET_MANIFEST.md` verbatim.

### SEO / metadata

- Unique `<title>` and `<meta name="description">` per page.
- `LocalBusiness` JSON-LD on the home page: name, ABN, both addresses, phone
  `+61459604470`, email, opening hours (Mo–Fr 07:00–17:00), `areaServed` for the
  six regions. Use the canonical values from `CONTENT_SOURCE.md` §1 — **not** the
  ones in the .docx.
- Open Graph + Twitter card images. `hero-kitchen-island-marble` works; a
  1200×630 crop would be better.
- **Add `capability.html` to `sitemap.xml`.** It is easy to forget.

### Things that must not break

- **`CNAME` stays.** Deleting it takes the custom domain down.
- **Never overwrite `public/images/suppliers/*` or `public/images/factory.png`.**
  User-uploaded.
- **Do not change `contact.js` field names** — they are a contract with the Apps
  Script endpoint.
- **Do not publish licence or insurance claims** (see `CONTENT_SOURCE.md` §1).
- **Do not invent copy.** If a section needs a line that is not in
  `CONTENT_SOURCE.md`, leave a TODO and report it.
- `preview.html` is an earlier redesign experiment (merged via PR #17). Read it
  for intent, then **delete it** as part of this work — a stray unlinked page on
  a live domain is a liability. Confirm before deleting if unsure.

### Process (from the repository's own `CLAUDE.md`)

1. Work on a branch, never commit to `main` directly.
2. Open a PR at the end.
3. Verify state before acting — `git status`, `ls`, read the file. Do not assume.
4. Commit convention: `feat(scope):`, `fix(scope):`, `docs(scope):`,
   `chore(scope):`, `style(scope):`.

---

## 7. Definition of done

- [ ] All five pages render correctly at 375 px, 768 px, 1024 px and 1440 px.
- [ ] The hero animation runs, and stops correctly under `prefers-reduced-motion`.
- [ ] All ten photographs are in place with the manifest's alt text, in
      `<picture>` with WebP + JPEG and explicit dimensions.
- [ ] Zero literal hex colours outside `tokens.css`.
- [ ] Contact details match `CONTENT_SOURCE.md` §1 on **every** page and in the
      JSON-LD — the old details appear nowhere.
- [ ] `capability.html` prints cleanly to A4.
- [ ] `sitemap.xml` includes every page; `CNAME` untouched.
- [ ] Keyboard navigation works end to end; focus is always visible.
- [ ] No console errors. Site works with JavaScript disabled (menu degrades to
      visible links; all content readable).
- [ ] `docs/design-system.html` reflects the components that now exist.

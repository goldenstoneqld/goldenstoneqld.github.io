# Golden Stone QLD — Approved Copy

Extracted verbatim from **Capability Statement Draft 01**, then reconciled
against the live site. Australian English throughout (colour, organise, centre,
metre, specialise).

**Rule for the build: do not invent copy.** Everything the site says must come
from this file or from `docs/brand/brand-book.md` in the website repository. If
a section needs a line that isn't here, leave a `<!-- TODO: copy needed -->`
comment and report it — do not write marketing filler.

---

## 1. Business facts — CANONICAL

The Capability Statement and the live site disagree on three fields. **The live
site wins** (decided at handoff). The .docx values are recorded only so nobody
"corrects" the site back to them later.

| Field | USE THIS | Draft 01 said (do not use) |
|---|---|---|
| Phone | **0459 604 470** (`tel:+61459604470`) | 0477 843 995 |
| Email | **sales@goldenstoneqld.com.au** | info@goldenstoneqld.com.au |
| Office | **37 Donna Ave, Rochedale South QLD 4123** | 6 Railway Ter, Milton QLD 4064 |

Agreed on both sources — use freely:

- **ABN:** 95 497 084 038
- **Factory:** 1819 Tarome Rd, Moorang QLD 4340
- **Hours:** Mon–Fri, 7:00 AM – 5:00 PM
- **Domain:** goldenstoneqld.com.au
- **Service area:** Brisbane · Gold Coast · Ipswich · Logan · Sunshine Coast ·
  Toowoomba · surrounding South East Queensland

> **Do not publish** any licence number, insurance cover, or accreditation
> claim. Draft 01 explicitly defers these: *"licensing and insurance details can
> be added once confirmed."*

---

## 2. Positioning

**Tagline (locked, brand book v2.0):**
> Crafted in Stone. Built to Last.

**One-line descriptor:**
> Premium stone masonry, in-house fabrication and professional installation for
> residential and commercial projects across South East Queensland.

**Voice:** Confident · Refined · Direct. Short sentences. Concrete nouns. No
superlatives that can't be evidenced — the photographs and the millimetre
figures do the persuading.

---

## 3. Who we are

**Section heading:** Who We Are
**Lead:** End-to-end stone capability from first measure through fabrication and
installation.

> Golden Stone QLD delivers premium stone solutions for homes, joineries,
> builders and commercial projects across South East Queensland. Our capability
> covers templating, planning, cutting, polishing, quality control, delivery and
> installation — managed as one connected workflow.
>
> With 15+ years of hands-on stone industry experience, the team combines
> practical craftsmanship with process automation and in-house equipment to
> improve accuracy, consistency and project visibility.

---

## 4. Core services

- Kitchen benchtops, islands and waterfall ends
- Bathroom vanities, niches and feature surfaces
- Alfresco, outdoor and custom stonework
- Residential and commercial fabrication
- On-site measure / template, delivery and installation

---

## 5. Capability at a glance — the stat row

Four figures. Render the numeral in Barlow Semi Condensed at display size, the
label in DM Sans small caps. This is the highest-value strip on the home page.

| Figure | Label |
|---|---|
| **15+** | Years of industry experience |
| **IN-HOUSE** | Cutting & polishing |
| **SEQ** | Six core regions serviced |
| **END-TO-END** | Measure to installation |

**Materials line:** Granite | Marble | Quartzite | Silica-free engineered stone options

> Note: "silica-free engineered stone options" matters commercially — Australia
> banned engineered stone containing crystalline silica from 1 July 2024. Keep
> the wording exactly as written; do not upgrade it to a compliance claim.

---

## 6. Integrated Fabrication Lifecycle (IFL) — the centrepiece section

**Heading:** Integrated Fabrication Lifecycle
**Lead:** Golden Stone's internal delivery framework connects the complete
fabrication journey in one controlled process.

> The IFL approach reduces hand-offs and keeps commercial, technical and
> production decisions connected from the first enquiry through final handover.

**The ten steps** — these are the spine of the redesign:

| # | Step | Descriptor |
|---|---|---|
| 01 | Enquiry | Scope & requirements |
| 02 | Quote | Clear commercial scope |
| 03 | Measure | Site template & checks |
| 04 | Plan | Design & fabrication planning |
| 05 | Material | Slab selection & allocation |
| 06 | Cut | Automated bridge saw |
| 07 | Polish | Edge processing & finishing |
| 08 | QC | Dimensional & finish check |
| 09 | Install | Delivery & professional install |
| 10 | Handover | Completion & close-out |

**Strapline under the ten steps:**
> One integrated workflow — from first enquiry to final installation.

**What this means for clients:**

- Clearer project ownership and communication
- Consistent technical information from measure to install
- Better coordination between material, fabrication and site timing
- Repeatable in-house cutting and polishing processes
- Visible quality gates before dispatch
- Scalable workflow for one-off and multi-unit work

---

## 7. In-house fabrication

**Heading:** In-House Fabrication
**Lead:** Professional-grade equipment gives Golden Stone direct control over
cutting, finishing and production quality.
**Location line:** Factory: 1819 Tarome Rd, Moorang QLD 4340

**Two equipment cards:**

- **CNC Bridge Saw** — Automated cutting capability for repeatable benchtops,
  islands, cut-outs, splashbacks and custom components.
- **Automated Polishing System** — Controlled edge processing and polishing to
  support consistent finish quality and efficient production.

**Fabrication capabilities:**

- Digital templating and fabrication planning
- Automated slab cutting and component preparation
- Sink, hob and appliance cut-outs
- Waterfall, mitred and profiled edge work
- Automated polishing and edge finishing
- Full-height splashbacks and feature surfaces
- Quality checks before delivery
- Capability from single jobs to multi-unit projects

**Caption:** In-house fabrication supports precision, consistency and direct
production control.

---

## 8. Selected projects

**Heading:** Selected Projects
**Lead:** A snapshot of recent finished work and the range of surfaces Golden
Stone can deliver.

| Project | Caption |
|---|---|
| Residential Kitchen | Large island, benchtops and integrated sink cut-out |
| Full-Height Splashback | Stone splashback paired with matching benchtop surfaces |
| Butler's Pantry | Continuous stone worktop with internal corner detailing |
| Outdoor / Alfresco | Stone benchtop and sink area for an outdoor setting |

---

## 9. Typical scope — the three-step client-facing summary

- **Measure & Template** — On-site confirmation of dimensions, access, cabinetry
  readiness and fabrication details.
- **Fabricate** — Cutting, edge processing, cut-outs, finishing and quality
  control completed in-house.
- **Deliver & Install** — Coordinated site delivery and professional
  installation to the agreed project scope.

---

## 10. People & quality

**Heading:** People, Quality & Contact
**Lead:** Trade experience, direct coordination and a practical focus on
accurate delivery.

**Caption pair:** Hands-on craftsmanship — supported by an integrated,
technology-enabled fabrication process.

**Team:**

- **Emerson** — Certificate III in Stonemasonry (CPC32320), a nationally
  recognised qualification, issued 09 June 2026.
- **Ralph** — Project Coordinator. Project coordination: 0459 604 470.

> The .docx listed Ralph's number as 0477 843 995. Per §1 the site publishes
> 0459 604 470 only. If Ralph genuinely has a separate direct line, confirm it
> before publishing a second number.

---

## 11. Trusted supplier network

Caesarstone | WK Stone | YDL Stone | Stone Ambassador | Better Stone

Logos already exist at `public/images/suppliers/` — **do not overwrite them.**

| Logo file | Links to |
|---|---|
| `caesarstone.png` | https://www.caesarstone.com.au |
| `wk-stone.png` | https://www.wkstone.com.au |
| `ydl-stone.png` | https://www.ydlstone.com.au |
| `stone-ambassador.webp` | https://www.stoneambassador.com.au |
| `better-stone.webp` | https://www.betterstone.com.au |

---

## 12. Why Golden Stone

- One connected workflow from quote to install
- In-house automated cutting and polishing
- Direct communication with a local Queensland team
- Residential, trade and commercial capability
- Clear scope, site coordination and quality checks
- Practical craftsmanship backed by 15+ years of experience

---

## 13. Closing call to action

**Heading:** Start your next project with Golden Stone QLD

**Contact block:**
> Office: 37 Donna Ave, Rochedale South QLD 4123
> Factory: 1819 Tarome Rd, Moorang QLD 4340
> 0459 604 470 | sales@goldenstoneqld.com.au | goldenstoneqld.com.au
> ABN 95 497 084 038

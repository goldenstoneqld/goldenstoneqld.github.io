# Golden Stone QLD — Website Redesign Handoff Package

Prepared in the IFL repository so the work is versioned alongside the source
material it draws on. **The execution happens in a different repository:**
`goldenstoneqld/goldenstoneqld.github.io`.

## Why this package exists

The redesign needs three inputs that live in three different places:

| Input | Source |
|---|---|
| Copy, positioning, real numbers | `Golden Stone QLD Capability Statement Draft 01.docx` (uploaded, extracted here) |
| Ten production photographs | Embedded in that same .docx (extracted and optimised here) |
| The "plan → 3D → stone" opening animation | IFL `static/css/app.css` + `templates/allauth/layouts/base.html` (ported here) |

None of those are reachable from a session opened on the website repository.
This package makes them portable.

## Contents

```
09_GOLDEN_STONE_WEBSITE/
├── README.md                  ← you are here
├── HANDOFF_PROMPT.md          ← paste this into the new session to start work
├── BRIEFING.md                ← the design + build brief (the main document)
├── CONTENT_SOURCE.md          ← every line of approved copy, AU English
├── ASSET_MANIFEST.md          ← the ten photos: naming, alt text, placement
└── assets/
    ├── images/                ← 20 files: 10 photos × {1600w, 800w} × {jpg, webp}
    └── hero-animation/
        ├── hero-animation.css ← portable, retheme-able, zero dependencies
        └── hero-animation.html← standalone preview + the markup to copy
```

## How to run the job

1. Open a **new Claude Code session with `goldenstoneqld/goldenstoneqld.github.io`
   as the initial source.** A session already holding `jlffigueiredo01-byte/IFL`
   cannot be granted push access to a repository under a different owner
   (`add_repo` rejects cross-owner attachment), so the website work needs its
   own session.
2. Upload `golden-stone-handoff.zip` (this folder, zipped) into that session.
3. Paste the contents of `HANDOFF_PROMPT.md` as the first message.

## Decisions already locked

These were settled before handoff. They are not open questions.

- **Brand stays Golden Stone.** Brass Gold `#B8922A`, Deep Black `#111111`,
  Warm Cream `#F5F0E8`, Barlow Semi Condensed + DM Sans. **No teal anywhere.**
  What IFL contributes is *rigour*, not colour: the animation (retinted gold),
  the token discipline, monospace for millimetre figures, and the vocabulary of
  a controlled process.
- **Contact details come from the live site, not the .docx.** The Capability
  Statement Draft 01 carries a different phone, email and office address; those
  are treated as stale. See `CONTENT_SOURCE.md` §1.
- **Scope is all four pages plus a new Capability page.**

## Provenance

- Capability Statement: Draft 01, ABN 95 497 084 038. Its closing note reads
  *"licensing and insurance details can be added once confirmed"* — so the site
  must not claim licence or insurance cover until Golden Stone supplies it.
- Animation: ported from IFL commit on branch `claude/goldenstone-repo-access-kkdda1`.
  The IFL original stays in place and is unmodified by this work.
